# Run

```bash
docker build -t personal-blog .
docker run --rm -p 3000:3000 personal-blog
```