const express = require('express');
const puppeteer = require('puppeteer');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

app.post('/visit', async (req, res) => {
  const { uri } = req.body;
  if (!uri) return res.status(400).json({ error: 'Missing uri' });

  const origin = 'http://web:5000/';  
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });

  const page = await browser.newPage();

  try {

    await page.goto(origin + uri, { waitUntil: 'networkidle2', timeout: 60000 });
    console.log(origin + uri)

    res.json({ success: true, message: 'Visited successfully' });
  } catch (err) {
    console.error('Error:', err);
    res.status(500).json({ error: 'Automation failed', details: err.message });
  } finally {
    await browser.close();
  }
});


app.listen(PORT,"0.0.0.0", () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
