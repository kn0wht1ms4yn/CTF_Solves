from flask import Flask, request, jsonify, render_template, session, redirect, url_for
import sqlite3
import hashlib
import os
import re
import ipaddress
from urllib.parse import urlparse
from datetime import timedelta

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', os.urandom(24))

app.config['SESSION_COOKIE_HTTPONLY'] = False
app.config['SESSION_COOKIE_SAMESITE'] = None
app.config['SESSION_COOKIE_SECURE'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=5)
app.config['SESSION_REFRESH_EACH_REQUEST'] = False

DB_PATH = '/data/main.db'

PASSWORD       = os.environ.get('PASSWORD')
SVC_ADMIN_PASSWORD  = os.environ.get('SVC_ADMIN_PASSWORD')
BOT_SECRET          = os.environ.get('BOT_SECRET', 'cJW4ZZmbqcGpRWUTIh3j2HNCfddQrB7J')


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    os.makedirs('/data', exist_ok=True)
    conn = get_db()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        hash_algo TEXT DEFAULT 'sha256',
        role TEXT DEFAULT 'user',
        email TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        content TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    erin_hash = hashlib.sha256(PASSWORD.encode()).hexdigest()
    c.execute(
        "INSERT INTO users (username, password_hash, hash_algo, role, email) VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash, hash_algo=excluded.hash_algo",
        ('erin', erin_hash, 'sha256', 'user', 'erin@securevault.internal')
    )

    admin_hash = hashlib.md5(SVC_ADMIN_PASSWORD.encode()).hexdigest()
    c.execute(
        "INSERT INTO users (username, password_hash, hash_algo, role, email) VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash, hash_algo=excluded.hash_algo",
        ('svc_admin', admin_hash, 'md5', 'admin', 'svc_admin@securevault.internal')
    )

    c.execute("SELECT id FROM users WHERE username = 'svc_admin'")
    admin_user = c.fetchone()
    if admin_user:
        c.execute("SELECT COUNT(*) FROM notes WHERE user_id = ?", (admin_user['id'],))
        if c.fetchone()[0] == 0:
            c.execute(
                "INSERT INTO notes (user_id, content) VALUES (?, ?)",
                (admin_user['id'], "Stepping out for lunch. Back shortly — keep an eye on transactions.")
            )

    conn.commit()
    conn.close()


def sanitize_note(content):
    content = re.sub(r'<script.*?>.*?</script>', '', content, flags=re.IGNORECASE | re.DOTALL)
    content = re.sub(r'<details[\s\S]*?>[\s\S]*?</details>', '', content, flags=re.IGNORECASE)
    content = re.sub(r'<details[^>]*>', '', content, flags=re.IGNORECASE)
    content = re.sub(r'</details>', '', content, flags=re.IGNORECASE)
    content = re.sub(r'javascript:', '', content, flags=re.IGNORECASE)
    content = re.sub(r'on(load|error|click|submit|focus|toggle|begin|end|mouse\w+|key\w+|input|change|drag\w*|drop|scroll|wheel|pointer\w*)=', '', content, flags=re.IGNORECASE)
    return content


BLOCKED_PRIVATE = [
    ipaddress.ip_network('10.0.0.0/8'),
    ipaddress.ip_network('172.16.0.0/12'),
    ipaddress.ip_network('192.168.0.0/16'),
    ipaddress.ip_network('169.254.0.0/16'),
]


def parse_numeric_host(host):
    if not host:
        raise ValueError('Missing host.')

    try:
        return ipaddress.ip_address(host)
    except ValueError:
        pass

    if re.fullmatch(r'0[xX][0-9a-fA-F]+', host):
        value = int(host, 16)
    elif re.fullmatch(r'0[0-7]+', host):
        value = int(host, 8)
    elif re.fullmatch(r'[0-9]+', host):
        value = int(host, 10)
    else:
        raise ValueError('Hostname must be a numeric IP address.')

    if value < 0 or value > 0xFFFFFFFF:
        raise ValueError('Numeric host is out of range.')

    return ipaddress.IPv4Address(value)


def is_ssrf_allowed(url):
    try:
        parsed = urlparse(url)
    except Exception:
        return False, "Invalid URL."

    if parsed.scheme != 'http':
        return False, "Only http scheme is permitted."

    host = parsed.hostname or ''
    port = parsed.port

    try:
        addr = parse_numeric_host(host)
    except ValueError as exc:
        return False, str(exc)

    if not addr.is_loopback:
        for net in BLOCKED_PRIVATE:
            try:
                if addr in net:
                    return False, "Access to private ranges is not permitted."
            except TypeError:
                pass
        return False, "Only loopback addresses are permitted."

    if port != 8080:
        return False, "Only port 8080 is accessible."

    return True, "ok"


@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')


@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()
    if not user:
        return jsonify({'status': 'error', 'message': 'Invalid username or password.'}), 401

    algo = user['hash_algo']
    if algo == 'sha256':
        match = hashlib.sha256(password.encode()).hexdigest() == user['password_hash']
    else:
        match = hashlib.md5(password.encode()).hexdigest() == user['password_hash']

    if not match:
        return jsonify({'status': 'error', 'message': 'Invalid username or password.'}), 401

    session.permanent = True
    session['user_id'] = user['id']
    session['username'] = user['username']
    session['role'] = user['role']
    return jsonify({'status': 'ok', 'redirect': '/dashboard'})


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


@app.route('/forgot-password', methods=['GET'])
def forgot_password_page():
    return render_template('forgot_password.html')


@app.route('/forgot-password', methods=['POST'])
def forgot_password():
    data = request.get_json()
    username = data.get('username', '').strip()
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    conn.close()
    if not user:
        return jsonify({'status': 'error', 'message': 'No account associated with that username.'}), 404

    # Admin hash is never exposed
    if user['role'] == 'admin':
        return jsonify({
            'status': 'ok',
            'message': 'Account found. Recovery information has been sent to the registered email.',
            'account': {
                'username': user['username'],
                'role': user['role']
            }
        })

    return jsonify({
        'status': 'ok',
        'message': 'Account found. Recovery information has been sent.',
        'account': {
            'username': user['username'],
            'role': user['role'],
            'password_hash': user['password_hash']
        }
    })


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    conn = get_db()
    is_admin = session.get('role') == 'admin'
    if is_admin:
        notes = conn.execute(
            "SELECT notes.id, notes.content, notes.created_at, users.username "
            "FROM notes JOIN users ON notes.user_id = users.id "
            "ORDER BY notes.created_at DESC"
        ).fetchall()
    else:
        notes = conn.execute(
            "SELECT notes.id, notes.content, notes.created_at, users.username "
            "FROM notes JOIN users ON notes.user_id = users.id "
            "WHERE users.username = 'svc_admin' "
            "ORDER BY notes.created_at DESC"
        ).fetchall()
    conn.close()
    return render_template('dashboard.html', username=session['username'], notes=notes, is_admin=is_admin)


@app.route('/notes', methods=['POST'])
def add_note():
    if 'user_id' not in session:
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    if session.get('role') == 'admin':
        return jsonify({'status': 'error', 'message': 'Administrative notes are read-only.'}), 403
    data = request.get_json() or {}
    content = data.get('content', '').strip()
    if not content:
        return jsonify({'status': 'error', 'message': 'Note cannot be empty.'}), 400
    if len(content) > 250:
        return jsonify({'status': 'error', 'message': 'Note exceeds maximum length of 250 characters.'}), 400
    sanitized = sanitize_note(content)
    conn = get_db()
    conn.execute("INSERT INTO notes (user_id, content) VALUES (?, ?)",
                 (session['user_id'], sanitized))
    conn.commit()
    conn.close()
    # Return success but note is NOT shown in the UI feed
    return jsonify({'status': 'ok', 'message': 'Note submitted.'})


@app.route('/notes/<int:note_id>', methods=['DELETE'])
def delete_note(note_id):
    if 'user_id' not in session:
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    conn = get_db()
    note = conn.execute(
        "SELECT notes.*, users.username FROM notes JOIN users ON notes.user_id = users.id WHERE notes.id = ?",
        (note_id,)
    ).fetchone()
    if not note:
        conn.close()
        return jsonify({'status': 'error', 'message': 'Note not found.'}), 404
    if note['username'] == 'svc_admin':
        conn.close()
        return jsonify({'status': 'error', 'message': 'The service admin note is locked.'}), 403
    if note['user_id'] != session['user_id'] and session.get('role') != 'admin':
        conn.close()
        return jsonify({'status': 'error', 'message': 'Forbidden.'}), 403
    conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
    conn.commit()
    conn.close()
    return jsonify({'status': 'ok'})


@app.route('/internal/cleanup-notes', methods=['POST'])
def cleanup_notes():
    if request.headers.get('X-Bot-Secret', '') != BOT_SECRET:
        return jsonify({'status': 'error', 'message': 'Forbidden'}), 403
    conn = get_db()
    conn.execute(
        "DELETE FROM notes WHERE user_id NOT IN "
        "(SELECT id FROM users WHERE username = 'svc_admin')"
    )
    conn.commit()
    conn.close()
    return jsonify({'status': 'ok'})


@app.route('/devtools')
def devtools():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    if session.get('role') != 'admin':
        return redirect(url_for('dashboard'))
    return render_template('devtools.html', username=session['username'])


@app.route('/devtools/fetch', methods=['POST'])
def devtools_fetch():
    if 'user_id' not in session or session.get('role') != 'admin':
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    data = request.get_json()
    url = data.get('url', '').strip()
    if not url:
        return jsonify({'status': 'error', 'message': 'No URL provided.'}), 400

    allowed, reason = is_ssrf_allowed(url)
    if not allowed:
        return jsonify({'status': 'error', 'message': f'Request blocked: {reason}'}), 400

    import urllib.request
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            body = resp.read().decode('utf-8', errors='replace')
        return jsonify({'status': 'ok', 'body': body})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500



@app.route('/internal/pending-check', methods=['GET'])
def pending_check():
    if request.headers.get('X-Bot-Secret', '') != BOT_SECRET:
        return jsonify({'status': 'error', 'message': 'Forbidden'}), 403
    conn = get_db()
    row = conn.execute(
        "SELECT COUNT(*) as cnt FROM notes WHERE user_id NOT IN "
        "(SELECT id FROM users WHERE username = 'svc_admin')"
    ).fetchone()
    conn.close()
    return jsonify({'pending': row['cnt'] > 0, 'count': row['cnt']})


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=False)

# This file is extended by a sed replacement below
