import time
import logging
import os
import requests
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logging.basicConfig(level=logging.INFO, format='[BOT] %(asctime)s %(message)s')

BASE_URL      = os.environ.get('MAIN_APP_URL', 'http://main-app:5000')
USERNAME      = os.environ.get('SVC_ADMIN_USERNAME', 'svc_admin')
PASSWORD      = os.environ.get('SVC_ADMIN_PASSWORD', '')
BOT_SECRET    = os.environ.get('BOT_SECRET', 'cJW4ZZmbqcGpRWUTIh3j2HNCfddQrB7J')
POLL_INTERVAL = int(os.environ.get('BOT_POLL_INTERVAL', '10'))  # seconds


def make_driver():
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--window-size=1280,800")
    service = Service("/usr/bin/chromedriver")
    driver = webdriver.Chrome(service=service, options=opts)
    driver.set_page_load_timeout(20)
    return driver


def has_pending_notes():
    """Returns True only if a non-admin user has posted a note."""
    try:
        resp = requests.get(
            f"{BASE_URL}/internal/pending-check",
            headers={"X-Bot-Secret": BOT_SECRET},
            timeout=5
        )
        if resp.status_code == 200:
            return resp.json().get('pending', False)
    except Exception:
        pass
    return False


def run_bot_session():
    driver = make_driver()
    try:
        driver.get(f"{BASE_URL}/")
        wait = WebDriverWait(driver, 10)

        wait.until(EC.presence_of_element_located((By.ID, "username"))).send_keys(USERNAME)
        driver.find_element(By.ID, "password").send_keys(PASSWORD)
        driver.find_element(By.CSS_SELECTOR, "button.btn").click()

        wait.until(EC.url_contains("/dashboard"))
        logging.info("Admin bot logged in and viewing dashboard.")
        time.sleep(5)

    except Exception as e:
        logging.error(f"Bot session error: {e}")
    finally:
        driver.quit()


def cleanup_notes():
    try:
        resp = requests.post(
            f"{BASE_URL}/internal/cleanup-notes",
            headers={"X-Bot-Secret": BOT_SECRET},
            timeout=10
        )
        logging.info(f"Notes cleaned up: {resp.status_code}")
    except Exception as e:
        logging.error(f"Cleanup failed: {e}")


def main():
    logging.info("Admin bot started — polling every %ds.", POLL_INTERVAL)
    while True:
        try:
            if has_pending_notes():
                logging.info("Pending note detected — visiting dashboard.")
                run_bot_session()
                cleanup_notes()
        except Exception as e:
            logging.error(f"Unhandled error: {e}")
        time.sleep(POLL_INTERVAL)


if __name__ == '__main__':
    time.sleep(15)
    main()
