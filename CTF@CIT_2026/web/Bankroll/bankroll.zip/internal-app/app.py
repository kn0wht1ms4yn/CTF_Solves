from flask import Flask, request, render_template_string
import sqlite3
import os
import re

app = Flask(__name__)
DB_PATH = '/data/internal.db'

FLAG = os.environ.get('FLAG', 'CIT{test_flag}')


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    os.makedirs('/data', exist_ok=True)
    conn = get_db()
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        department TEXT,
        status TEXT
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS secrets (
        id INTEGER PRIMARY KEY,
        secret TEXT
    )''')
    c.execute("INSERT OR IGNORE INTO employees VALUES (1, 'Alice Johnson', 'Engineering', 'Active')")
    c.execute("INSERT OR IGNORE INTO employees VALUES (2, 'Bob Martinez', 'Finance', 'Active')")
    c.execute("INSERT OR IGNORE INTO employees VALUES (3, 'Carol Smith', 'HR', 'Inactive')")
    c.execute("INSERT OR IGNORE INTO employees VALUES (4, 'David Lee', 'Security', 'Active')")
    c.execute("INSERT OR IGNORE INTO secrets VALUES (1, ?)", (FLAG,))
    conn.commit()
    conn.close()

KEYWORDS = {
    "union", "select", "from", "where",
    "drop", "insert", "delete", "update",
    "exec", "execute", "load_file",
    "outfile", "dumpfile"
}

def is_bad_casing(word: str) -> bool:
    return word.islower() or word.isupper()


def waf_check(value: str) -> bool:
    for word in re.findall(r'\b\w+\b', value):
        if word.lower() in KEYWORDS:
            if is_bad_casing(word):
                return True

    if "--" in value:
        return True

    return False


PAGE = '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<title>SecureVault Internal Portal</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #0f172a; color: #e2e8f0; font-family: 'Segoe UI', sans-serif; padding: 40px 24px; }
  .container { max-width: 860px; margin: 0 auto; }
  .header { margin-bottom: 32px; border-bottom: 1px solid #1e293b; padding-bottom: 20px; }
  .header h1 { font-size: 1.5rem; color: #f8fafc; margin-bottom: 4px; }
  .header p { color: #64748b; font-size: 0.88rem; }
  .badge { display: inline-block; background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.3); color: #f87171; font-size: 0.7rem; padding: 2px 8px; border-radius: 4px; margin-left: 8px; }
  .search-bar { display: flex; gap: 10px; margin-bottom: 24px; }
  .search-bar input { flex: 1; padding: 10px 14px; background: #1e293b; border: 1px solid #334155; border-radius: 6px; color: #e2e8f0; font-size: 0.9rem; outline: none; }
  .search-bar input:focus { border-color: #3b82f6; }
  .search-bar button { padding: 10px 20px; background: #3b82f6; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-size: 0.88rem; }
  .search-bar button:hover { background: #2563eb; }
  table { width: 100%; border-collapse: collapse; background: #1e293b; border-radius: 8px; overflow: hidden; }
  th { background: #0f172a; color: #94a3b8; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.8px; padding: 12px 16px; text-align: left; }
  td { padding: 12px 16px; font-size: 0.88rem; border-top: 1px solid #1e293b; }
  tr:hover td { background: rgba(59,130,246,0.05); }
  .error { color: #f87171; background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.2); border-radius: 6px; padding: 12px; margin-bottom: 16px; font-size: 0.88rem; font-family: monospace; }
  .empty { color: #64748b; text-align: center; padding: 40px; font-size: 0.9rem; }
  .footer { margin-top: 32px; color: #334155; font-size: 0.78rem; text-align: center; }
  .waf-block { color: #fbbf24; background: rgba(251,191,36,0.08); border: 1px solid rgba(251,191,36,0.2); border-radius: 6px; padding: 12px; margin-bottom: 16px; font-size: 0.88rem; }
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>Internal Employee Directory <span class="badge">INTERNAL ONLY</span></h1>
    <p>Search the employee database. This service is not accessible from the public internet.</p>
  </div>
  <form method="get" action="/search">
    <div class="search-bar">
      <input type="text" name="q" value="{{ query|e }}" placeholder="Search by employee name..." />
      <button type="submit">Search</button>
    </div>
  </form>
  {% if waf_blocked %}
  <div class="waf-block">&#x26A0; Request blocked by security filter.</div>
  {% endif %}
  {% if error %}
  <div class="error">{{ error }}</div>
  {% endif %}
  {% if results is not none %}
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Department</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      {% if results %}
        {% for row in results %}
        <tr>
          {% for col in row %}
          <td>{{ col }}</td>
          {% endfor %}
        </tr>
        {% endfor %}
      {% else %}
        <tr><td colspan="4" class="empty">No records found.</td></tr>
      {% endif %}
    </tbody>
  </table>
  {% endif %}
  <div class="footer">SecureVault Internal Services &middot; Unauthorized access is prohibited</div>
</div>
</body>
</html>
'''


@app.route('/')
def index():
    return render_template_string(PAGE, query='', results=None, error=None, waf_blocked=False)


@app.route('/search')
def search():
    q = request.args.get('q', '')
    error = None
    results = None
    waf_blocked = False

    if q:
        if waf_check(q):
            waf_blocked = True
            return render_template_string(PAGE, query=q, results=None, error=None, waf_blocked=True)
        try:
            conn = get_db()
            sql = "SELECT id, name, department, status FROM employees WHERE name = '" + q + "'"
            cur = conn.cursor()
            cur.execute(sql)
            results = cur.fetchall()
            results = [list(row) for row in results]
            conn.close()
        except Exception as e:
            error = str(e)
            results = []

    return render_template_string(PAGE, query=q, results=results, error=error, waf_blocked=waf_blocked)


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=8080, debug=False)